//
//  main.c
//  2.73-redo
//
//  Created by Ram Yadav on 4/8/17.
//  Copyright © 2017 Ram Yadav. All rights reserved.
//

int saturating_add(int x, int y) {
    int size = (sizeof(int) << 3) - 1;
    int sum;
    
    int overflow = __builtin_add_overflow(x, y, &sum);
    int mask_for_overflow = ((overflow << size) >> size);
    
    int x_negative_mask = (x >> size);
    int y_negative_mask = (y >> size);
    int sum_negative_mask = (sum >> size);
    
    int positive_over = ~x_negative_mask & ~y_negative_mask & sum_negative_mask;
    int negative_over = x_negative_mask & y_negative_mask & ~sum_negative_mask;
    
    return (positive_over & INT_MAX) | (negative_over & INT_MIN) | (~mask_for_overflow & sum);
}


